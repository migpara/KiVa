package com.example.kiva;

import static android.content.ContentValues.TAG;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.List;

public class BlogAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_MY_MESSAGE = 1;
    private static final int VIEW_TYPE_OTHERS_MESSAGE = 2;
    private Context context;
    private List<Message> messages;
    private String currentUser;
    private boolean isProfessor;
    private String centroId;

    public BlogAdapter(Context context,List<Message> messages, String currentUser,boolean isProfessor,String centroId) {
        this.context = context;
        this.messages = messages;
        this.currentUser = currentUser;
        this.isProfessor = isProfessor;
        this.centroId = centroId;
    }
    public void addMessage(Message message) {
        messages.add(message);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messages.get(position);
        if (message.getUserId().equals(currentUser)) {
            return VIEW_TYPE_MY_MESSAGE;
        } else {
            return VIEW_TYPE_OTHERS_MESSAGE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == VIEW_TYPE_MY_MESSAGE) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_message, parent, false);
            return new MyMessageViewHolder(view);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.vistamensaje, parent, false);
            return new OthersMessageViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messages.get(position);

        SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");

        if (holder.getItemViewType() == VIEW_TYPE_MY_MESSAGE) {
            ((MyMessageViewHolder) holder).content.setText(message.getContent());
            ((MyMessageViewHolder) holder).timestamp.setText(dateFormat.format(message.getTimestamp()));
        } else {
            ((OthersMessageViewHolder) holder).content.setText(message.getContent());
            ((OthersMessageViewHolder) holder).timestamp.setText(dateFormat.format(message.getTimestamp()));
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public  class MyMessageViewHolder extends RecyclerView.ViewHolder {
        TextView content;
        TextView timestamp;

        public MyMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            content = itemView.findViewById(R.id.my_text_message);
            timestamp = itemView.findViewById(R.id.my_text_message_time);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMessageOptionsDialog(getAdapterPosition());
                }
            });
        }
    }

    public  class OthersMessageViewHolder extends RecyclerView.ViewHolder {
        TextView content;
        TextView timestamp;

        public OthersMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            content = itemView.findViewById(R.id.text_message);
            timestamp = itemView.findViewById(R.id.text_message_time);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMessageOptionsDialog(getAdapterPosition());
                }
            });
        }
    }
    public void showMessageOptionsDialog(final int position) {
        // Revisa si el usuario es un profesor antes de mostrar el cuadro de diálogo
        if (isProfessor) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Selecciona una opción");

            String[] options = {"Editar", "Eliminar"};
            builder.setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) { // Editar
                        showEditMessageDialog(position);
                    } else if (which == 1) { // Eliminar
                        deleteMessage(position);
                    }
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    private void showEditMessageDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Editar mensaje");

        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(messages.get(position).getContent());
        builder.setView(input);

        builder.setPositiveButton("Actualizar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newContent = input.getText().toString().trim();
                updateMessage(position, newContent+"(editado por un profesor)");
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void updateMessage(int position, String newContent) {
        Message message = messages.get(position);
        message.setContent(newContent);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference messageRef = db.collection("CentroEscolar").document(centroId)
                .collection("mensajes").document(message.getId());

        messageRef.update("content", newContent)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Mensaje actualizado con éxito");
                        notifyDataSetChanged();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error al actualizar el mensaje", e);
                    }
                });
    }

    private void deleteMessage(int position) {
        Message message = messages.get(position);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference messageRef = db.collection("CentroEscolar").document(centroId)
                .collection("mensajes").document(message.getId());

        messageRef.delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Mensaje eliminado con éxito");
                        messages.remove(position);
                        notifyDataSetChanged();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error al eliminar el mensaje", e);
                    }
                });
    }


}


