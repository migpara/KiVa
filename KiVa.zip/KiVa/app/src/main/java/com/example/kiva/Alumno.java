package com.example.kiva;

public class Alumno {
    private String codigo;
    private String nombre;
    private String ultimoMensaje;

    public Alumno(String codigo, String nombre, String ultimoMensaje) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ultimoMensaje = ultimoMensaje;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo
    ) {
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getUltimoMensaje() {
        return ultimoMensaje;
    }
    public void setUltimoMensaje(String ultimoMensaje) {
        this.ultimoMensaje = ultimoMensaje;
    }
}