package com.example.kiva;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView logo=findViewById(R.id.txtLogo);
        Animation animacion= AnimationUtils.loadAnimation(this, R.anim.animation);
        logo.startAnimation(animacion);
        ProgressBar barra=findViewById(R.id.progressBar);
        Animation animacion2= AnimationUtils.loadAnimation(this, R.anim.animation2);
        logo.startAnimation(animacion2);

    }
    public boolean onTouchEvent(MotionEvent e) {
        Intent intent= new Intent (this, Login.class);
        startActivity(intent);



        return true;
    }
}