package com.example.kiva;

public class Reporte {
    private String queHaPasado;
    private String quienNecesitaAyuda;
    private String dondeCuando;
    private String quienLoHaHecho;
    private String tipoProblema;
    private String imageUrl;

    public Reporte() {}

    public Reporte(String queHaPasado, String quienNecesitaAyuda, String dondeCuando, String quienLoHaHecho, String tipoProblema, String imageUrl) {
        this.queHaPasado = queHaPasado;
        this.quienNecesitaAyuda = quienNecesitaAyuda;
        this.dondeCuando = dondeCuando;
        this.quienLoHaHecho = quienLoHaHecho;
        this.tipoProblema = tipoProblema;
        this.imageUrl = imageUrl;
    }

    public String getQueHaPasado() {
        return queHaPasado;
    }

    public void setQueHaPasado(String queHaPasado) {
        this.queHaPasado = queHaPasado;
    }

    public String getQuienNecesitaAyuda() {
        return quienNecesitaAyuda;
    }

    public void setQuienNecesitaAyuda(String quienNecesitaAyuda) {
        this.quienNecesitaAyuda = quienNecesitaAyuda;
    }

    public String getDondeCuando() {
        return dondeCuando;
    }

    public void setDondeCuando(String dondeCuando) {
        this.dondeCuando = dondeCuando;
    }

    public String getQuienLoHaHecho() {
        return quienLoHaHecho;
    }

    public void setQuienLoHaHecho(String quienLoHaHecho) {
        this.quienLoHaHecho = quienLoHaHecho;
    }

    public String getTipoProblema() {
        return tipoProblema;
    }

    public void setTipoProblema(String tipoProblema) {
        this.tipoProblema = tipoProblema;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
