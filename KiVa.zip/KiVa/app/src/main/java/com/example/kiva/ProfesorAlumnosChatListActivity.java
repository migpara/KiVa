package com.example.kiva;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class ProfesorAlumnosChatListActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private String centro;
    private String profesorCodigo;
    private ImageButton btnatras;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profesor_alumnos_chat_list);

        Bundle extras = getIntent().getExtras();
        centro = extras.getString("centro");
        profesorCodigo = extras.getString("usuario");

        btnatras=findViewById(R.id.imgAtras);
        btnatras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mRecyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference alumnosRef = db.collection("CentroEscolar").document(centro).collection("alumnos");

        alumnosRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                List<Alumno> alumnos = new ArrayList<>();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    String alumnoCodigo = document.getId();
                    String nombre = document.getString("nombre");
                    db.collection("CentroEscolar").document(centro).collection("alumnos").document(alumnoCodigo)
                            .collection("mensajes").orderBy("timestamp", Query.Direction.DESCENDING).limit(1)
                            .get().addOnCompleteListener(messageTask -> {
                                if (messageTask.isSuccessful() && messageTask.getResult().size() > 0) {
                                    DocumentSnapshot messageDocument = messageTask.getResult().getDocuments().get(0);
                                    String ultimoMensaje = messageDocument.getString("content");
                                    Alumno alumno = new Alumno(alumnoCodigo, nombre, ultimoMensaje);
                                    alumnos.add(alumno);
                                    updateAdapter(alumnos); // Llamada a una nueva función que actualiza el adaptador
                                }
                            });
                }
            }
        });


    }
    private void updateAdapter(List<Alumno> alumnos) {
        AlumnosChatListAdapter adapter = new AlumnosChatListAdapter(alumnos, (View v, int position) -> {
            Alumno alumno = alumnos.get(position);
            Intent intent = new Intent(ProfesorAlumnosChatListActivity.this, ProfesorChatActivity.class);
            intent.putExtra("centro", centro);
            intent.putExtra("profesorCodigo", profesorCodigo);
            intent.putExtra("alumnoCodigo", alumno.getCodigo());
            startActivity(intent);
        });
        mRecyclerView.setAdapter(adapter);
    }

}
