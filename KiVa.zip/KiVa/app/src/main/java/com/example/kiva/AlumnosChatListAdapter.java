package com.example.kiva;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AlumnosChatListAdapter extends RecyclerView.Adapter<AlumnosChatListAdapter.ViewHolder> {

    private List<Alumno> alumnos;
    private OnItemClickListener onItemClickListener;

    public AlumnosChatListAdapter(List<Alumno> alumnos, OnItemClickListener onItemClickListener) {
        this.alumnos = alumnos;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_alumno_chat, parent, false);
        return new ViewHolder(view, onItemClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Alumno alumno = alumnos.get(position);
        holder.alumnoNameTextView.setText(alumno.getCodigo());
        holder.ultimoMensajeTextView.setText(alumno.getUltimoMensaje());
    }


    @Override
    public int getItemCount() {
        return alumnos.size();
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView alumnoNameTextView;
        TextView ultimoMensajeTextView;
        OnItemClickListener onItemClickListener;

        public ViewHolder(@NonNull View itemView, OnItemClickListener onItemClickListener) {
            super(itemView);
            alumnoNameTextView = itemView.findViewById(R.id.alumno_name);
            ultimoMensajeTextView = itemView.findViewById(R.id.ultimo_mensaje);
            this.onItemClickListener = onItemClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onItemClickListener.onItemClick(v, getAdapterPosition());
        }
    }
}
