package com.example.kiva;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ProfReporte extends AppCompatActivity {
    private RecyclerView recyclerViewReportes;
    private ReportAdapter reportAdapter;
    private FirebaseFirestore firestore;
    private List<Map<String, Object>> reportList;
    private static final String TAG = "activity_prof_reporte";
    private String centro;
    private ImageButton btnAtras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prof_reporte);

        recyclerViewReportes = findViewById(R.id.recyclerViewReportes);
        recyclerViewReportes.setHasFixedSize(true);
        recyclerViewReportes.setLayoutManager(new LinearLayoutManager(this));

        reportList = new ArrayList<>();
        reportAdapter = new ReportAdapter(reportList, this);
        recyclerViewReportes.setAdapter(reportAdapter);

        Bundle extras = getIntent().getExtras();
        centro = extras.getString("centro");
        btnAtras=findViewById(R.id.imgAtras);

        firestore = FirebaseFirestore.getInstance();
        getReports();

        btnAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    private void getReports() {
        CollectionReference reportsRef = firestore.collection("CentroEscolar").document(centro).collection("Formularios");

        reportsRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (queryDocumentSnapshots != null) {
                    for (DocumentChange dc : queryDocumentSnapshots.getDocumentChanges()) {
                        DocumentSnapshot documentSnapshot = dc.getDocument();
                        Map<String, Object> report = documentSnapshot.getData();

                        switch (dc.getType()) {
                            case ADDED:
                                reportList.add(report);
                                break;
                            case MODIFIED:
                                int index = reportList.indexOf(report);
                                if (index != -1) {
                                    reportList.set(index, report);
                                }
                                break;
                            case REMOVED:
                                reportList.remove(report);
                                break;
                        }
                    }
                    reportAdapter.notifyDataSetChanged();
                } else {
                    Log.d(TAG, "No data");
                }
            }
        });
    }
}